#!/usr/bin/env bash

export SESSION_SECRET="IE^Bx3P2~%^9n6dE$stI-{2ymTN[5"
export MEETUP_KEY="1d358576f466d6034e313546183479"
# export MONGODB="mongodb://localhost:27017/feedback"
export TOKEN="1ehS9nY6j4chTH28w5513Gcyh7wWrE"
