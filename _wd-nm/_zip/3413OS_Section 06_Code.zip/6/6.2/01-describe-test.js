describe('Array', function () {
    describe('#indexOf()', function () {
    });
});
