function foo() {
    return foo();
}

foo();
