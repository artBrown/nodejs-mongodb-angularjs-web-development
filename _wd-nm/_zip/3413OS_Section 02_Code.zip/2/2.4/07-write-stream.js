'use strict';

for (let i = 0; i < 5; i++) {
    console.log(
        process.stdout.write('i value is = ' + i + '\n', 'utf8')
    );
}
