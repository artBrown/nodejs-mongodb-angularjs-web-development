module.exports = 'Hello string';
