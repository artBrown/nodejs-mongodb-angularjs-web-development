'use strict';

const Hello = {
    name: 'World',
    say: function (name) {
        console.log('Hello', name);
    }
}

module.exports = Hello;
