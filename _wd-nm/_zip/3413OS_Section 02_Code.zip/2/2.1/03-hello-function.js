module.exports = function () {
    console.log('Hello function');
}
