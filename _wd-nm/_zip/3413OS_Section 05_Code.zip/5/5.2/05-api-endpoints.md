# Events

* Create
* Read
* Update
* Delete
* List
* Feedbacks
    - Create
    - Read
    - Update
    - Delete
    - List

# Feedbacks

* List
* Delete
