'use strict';

const express = require('express');
const app = express();
const router = express.Router();

app.get('/events', function (request, response) {
    //
});

router.get('/events', function (request, response) {
    //
});
