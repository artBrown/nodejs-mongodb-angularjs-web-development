#!/usr/bin/env node

let error = true;

if (error) {
    console.log('Error occurred');
    console.log('Exiting with code higher than 0');

    process.exit(1);
}

process.exit(0);
