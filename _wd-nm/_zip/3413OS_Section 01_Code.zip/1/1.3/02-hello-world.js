#!/usr/bin/env node

console.log('Hello World!');
