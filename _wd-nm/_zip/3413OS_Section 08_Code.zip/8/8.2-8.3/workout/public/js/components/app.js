'use strict';

const React = require('react');
const Info = require('./info');

const App = React.createClass({
    render: function () {
        return (
            <Info />
        );
    }
});

module.exports = App;
