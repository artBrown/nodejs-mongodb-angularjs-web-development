# Hello Workout


Get a random workout with wanted intensity.


This is used to display how to publish a new package to an npm.
